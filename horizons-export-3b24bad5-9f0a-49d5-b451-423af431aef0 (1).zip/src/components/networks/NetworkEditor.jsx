import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';

const NetworkEditor = ({ isOpen, onOpenChange, network, onSave }) => {
  const [formData, setFormData] = useState({
    id: null,
    name: '',
    chainType: 'EVM',
    rpcUrl: '',
    faucetAmount: '',
    cooldownSec: '',
    explorerApiBase: '',
    statusEndpoint: '',
    isActive: true
  });

  useEffect(() => {
    if (network) {
      setFormData({
        id: network.id,
        name: network.name,
        chainType: network.chainType,
        rpcUrl: network.rpcUrl,
        faucetAmount: network.faucetAmount.toString(),
        cooldownSec: network.cooldownSec.toString(),
        explorerApiBase: network.explorerApiBase,
        statusEndpoint: network.statusEndpoint,
        isActive: network.isActive
      });
    } else {
      resetForm();
    }
  }, [network, isOpen]);

  const resetForm = () => {
    setFormData({
      id: null,
      name: '',
      chainType: 'EVM',
      rpcUrl: '',
      faucetAmount: '',
      cooldownSec: '',
      explorerApiBase: '',
      statusEndpoint: '',
      isActive: true
    });
  };

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (value) => {
    setFormData(prev => ({ ...prev, chainType: value }));
  };

  const handleSwitchChange = (checked) => {
    setFormData(prev => ({ ...prev, isActive: checked }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>
            {network ? 'Edit Network' : 'Tambah Network Baru'}
          </DialogTitle>
          <DialogDescription>
            {network ? 'Perbarui informasi network' : 'Tambahkan network blockchain baru ke sistem'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Nama Network</Label>
              <Input id="name" value={formData.name} onChange={handleChange} placeholder="Ethereum Mainnet" required />
            </div>
            <div>
              <Label htmlFor="chainType">Tipe Chain</Label>
              <Select value={formData.chainType} onValueChange={handleSelectChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="EVM">EVM</SelectItem>
                  <SelectItem value="COSMOS">COSMOS</SelectItem>
                  <SelectItem value="OTHER">OTHER</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label htmlFor="rpcUrl">RPC URL</Label>
            <Input id="rpcUrl" value={formData.rpcUrl} onChange={handleChange} placeholder="https://mainnet.infura.io/v3/..." required />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="faucetAmount">Faucet Amount</Label>
              <Input id="faucetAmount" value={formData.faucetAmount} onChange={handleChange} placeholder="0.1" type="number" step="0.01" required />
            </div>
            <div>
              <Label htmlFor="cooldownSec">Cooldown (detik)</Label>
              <Input id="cooldownSec" value={formData.cooldownSec} onChange={handleChange} placeholder="86400" type="number" required />
            </div>
          </div>

          <div>
            <Label htmlFor="explorerApiBase">Explorer API Base</Label>
            <Input id="explorerApiBase" value={formData.explorerApiBase} onChange={handleChange} placeholder="https://api.etherscan.io" required />
          </div>

          <div>
            <Label htmlFor="statusEndpoint">Status Endpoint</Label>
            <Input id="statusEndpoint" value={formData.statusEndpoint} onChange={handleChange} placeholder="https://api.etherscan.io/api" required />
          </div>

          <div className="flex items-center space-x-2">
            <Switch id="isActive" checked={formData.isActive} onCheckedChange={handleSwitchChange} />
            <Label htmlFor="isActive">Network Aktif</Label>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Batal
            </Button>
            <Button type="submit" className="bg-orange-500 hover:bg-orange-600">
              {network ? 'Update' : 'Tambah'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default NetworkEditor;
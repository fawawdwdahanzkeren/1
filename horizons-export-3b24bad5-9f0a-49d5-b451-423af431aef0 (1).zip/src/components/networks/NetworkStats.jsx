import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const NetworkStats = ({ networks }) => {
  const totalNetworks = networks.length;
  const activeNetworks = networks.filter(n => n.isActive).length;
  const chainTypes = {
    EVM: networks.filter(n => n.chainType === 'EVM').length,
    COSMOS: networks.filter(n => n.chainType === 'COSMOS').length,
    OTHER: networks.filter(n => n.chainType === 'OTHER').length,
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Total Networks</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-orange-400">{totalNetworks}</div>
          <p className="text-sm text-gray-400">Jaringan terdaftar</p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Active Networks</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-green-400">{activeNetworks}</div>
          <p className="text-sm text-gray-400">Jaringan aktif</p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Chain Types</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {Object.entries(chainTypes).map(([type, count]) => (
              <div key={type} className="flex justify-between">
                <span className="text-sm text-gray-400">{type}</span>
                <span className="text-sm text-white">{count}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default NetworkStats;
import React from 'react';
import { motion } from 'framer-motion';
import { Network, Edit, Trash2, Activity } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const NetworkList = ({ networks, onEdit, onDelete }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'online': return 'bg-green-400';
      case 'maintenance': return 'bg-yellow-400';
      case 'offline': return 'bg-red-400';
      default: return 'bg-gray-400';
    }
  };

  const getChainTypeColor = (type) => {
    switch (type) {
      case 'EVM': return 'bg-blue-500';
      case 'COSMOS': return 'bg-purple-500';
      case 'OTHER': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {networks.map((network, index) => (
        <motion.div
          key={network.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card className="hover-lift h-full flex flex-col">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2 flex-1 min-w-0">
                  <Network className="w-5 h-5 text-orange-400 flex-shrink-0" />
                  <CardTitle className="text-lg truncate">{network.name}</CardTitle>
                </div>
                <div className="flex space-x-1 flex-shrink-0">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onEdit(network)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onDelete(network.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="flex items-center space-x-2 mt-2">
                <span className={`px-2 py-1 rounded-full text-xs text-white ${getChainTypeColor(network.chainType)}`}>
                  {network.chainType}
                </span>
                <div className="flex items-center space-x-1">
                  <div className={`w-2 h-2 rounded-full ${getStatusColor(network.status)}`}></div>
                  <span className="text-xs text-gray-400 capitalize">{network.status}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex-grow flex flex-col justify-between">
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-gray-400">Faucet Amount</p>
                  <p className="text-sm text-white">{network.faucetAmount} tokens</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Cooldown</p>
                  <p className="text-sm text-white">{Math.floor(network.cooldownSec / 3600)}h</p>
                </div>
              </div>
              <div className="flex items-center justify-between mt-4">
                <span className="text-xs text-gray-400">Status</span>
                <div className="flex items-center space-x-1">
                  <Activity className={`w-3 h-3 ${network.isActive ? 'text-green-400' : 'text-red-400'}`} />
                  <span className={`text-xs ${network.isActive ? 'text-green-400' : 'text-red-400'}`}>
                    {network.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
};

export default NetworkList;
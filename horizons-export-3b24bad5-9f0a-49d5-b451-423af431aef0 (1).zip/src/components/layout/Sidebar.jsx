
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Home, 
  Globe, 
  Network, 
  FileText, 
  Droplets, 
  Search, 
  Settings,
  X,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';

const Sidebar = ({ isOpen, onClose, animationsEnabled, onToggleAnimations }) => {
  const location = useLocation();

  const menuItems = [
    { icon: Home, label: 'Overview', path: '/' },
    { icon: Globe, label: 'Sites', path: '/sites' },
    { icon: Network, label: 'Networks', path: '/networks' },
    { icon: FileText, label: 'Docs', path: '/docs' },
    { icon: Droplets, label: 'Faucet', path: '/faucet' },
    { icon: Search, label: 'Explorer', path: '/explorer' },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  const sidebarVariants = {
    open: { x: 0 },
    closed: { x: '-100%' }
  };

  return (
    <>
      {/* Mobile Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={onClose}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside
        variants={sidebarVariants}
        animate={isOpen ? 'open' : 'closed'}
        initial="closed"
        className="fixed lg:static inset-y-0 left-0 z-50 w-64 sidebar-gradient border-r border-orange-500/20 lg:translate-x-0"
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-orange-500/20">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold gradient-text">KerenStake</h1>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="lg:hidden text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={onClose}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 group ${
                    isActive
                      ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                      : 'text-gray-300 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'text-orange-400' : 'text-gray-400 group-hover:text-orange-400'}`} />
                  <span className="font-medium">{item.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* Animation Toggle */}
          <div className="p-4 border-t border-orange-500/20">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Animasi</span>
              <Switch
                checked={animationsEnabled}
                onCheckedChange={onToggleAnimations}
              />
            </div>
          </div>
        </div>
      </motion.aside>
    </>
  );
};

export default Sidebar;

import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const DocsEditor = ({ isOpen, onOpenChange, doc, onSave }) => {
  const [formData, setFormData] = useState({
    id: null,
    title: '',
    slug: '',
    content: '',
    category: '',
    published: true
  });

  useEffect(() => {
    if (doc) {
      setFormData({
        id: doc.id,
        title: doc.title,
        slug: doc.slug,
        content: doc.content,
        category: doc.category,
        published: doc.published
      });
    } else {
      resetForm();
    }
  }, [doc, isOpen]);

  const resetForm = () => {
    setFormData({
      id: null,
      title: '',
      slug: '',
      content: '',
      category: '',
      published: true
    });
  };

  const generateSlug = (title) => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  };

  const handleTitleChange = (e) => {
    const title = e.target.value;
    setFormData(prev => ({
      ...prev,
      title,
      slug: generateSlug(title)
    }));
  };

  const renderMarkdownPreview = (content) => {
    return content
      .replace(/^# (.*$)/gim, '<h1 class="text-2xl font-bold mb-4">$1</h1>')
      .replace(/^## (.*$)/gim, '<h2 class="text-xl font-semibold mb-3">$1</h2>')
      .replace(/^### (.*$)/gim, '<h3 class="text-lg font-medium mb-2">$1</h3>')
      .replace(/\*\*(.*)\*\*/gim, '<strong>$1</strong>')
      .replace(/\*(.*)\*/gim, '<em>$1</em>')
      .replace(/`([^`]+)`/gim, '<code class="bg-muted text-muted-foreground px-1 rounded">$1</code>')
      .replace(/\n/gim, '<br />');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>
            {doc ? 'Edit Halaman' : 'Tambah Halaman Baru'}
          </DialogTitle>
          <DialogDescription>
            {doc ? 'Perbarui konten dokumentasi' : 'Buat halaman dokumentasi baru'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 overflow-y-auto flex-grow pr-2">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="title">Judul</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={handleTitleChange}
                placeholder="Getting Started"
                required
              />
            </div>
            <div>
              <Label htmlFor="slug">Slug</Label>
              <Input
                id="slug"
                value={formData.slug}
                onChange={(e) => setFormData(prev => ({ ...prev, slug: e.target.value }))}
                placeholder="getting-started"
                required
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="category">Kategori</Label>
            <Input
              id="category"
              value={formData.category}
              onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
              placeholder="Basics"
              required
            />
          </div>

          <div>
            <Label htmlFor="content">Konten (MDX)</Label>
            <Tabs defaultValue="edit" className="w-full">
              <TabsList>
                <TabsTrigger value="edit">Edit</TabsTrigger>
                <TabsTrigger value="preview">Preview</TabsTrigger>
              </TabsList>
              <TabsContent value="edit">
                <Textarea
                  id="content"
                  value={formData.content}
                  onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="# Judul Halaman&#10;&#10;Konten dokumentasi dalam format MDX..."
                  className="min-h-[300px] font-mono"
                  required
                />
              </TabsContent>
              <TabsContent value="preview">
                <div 
                  className="min-h-[300px] p-4 border rounded-md bg-gray-900 text-white prose prose-invert"
                  dangerouslySetInnerHTML={{ __html: renderMarkdownPreview(formData.content) }}
                />
              </TabsContent>
            </Tabs>
          </div>

          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="published"
              checked={formData.published}
              onChange={(e) => setFormData(prev => ({ ...prev, published: e.target.checked }))}
              className="rounded"
            />
            <Label htmlFor="published">Publikasikan</Label>
          </div>
        </form>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
            Batal
          </Button>
          <Button type="submit" form="docs-editor-form" onClick={handleSubmit} className="bg-orange-500 hover:bg-orange-600">
            {doc ? 'Update' : 'Buat'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default DocsEditor;
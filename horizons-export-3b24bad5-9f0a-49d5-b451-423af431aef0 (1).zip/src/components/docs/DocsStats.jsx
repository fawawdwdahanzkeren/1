import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const DocsStats = ({ docs }) => {
  const totalPages = docs.length;
  const publishedPages = docs.filter(d => d.published).length;
  const draftPages = totalPages - publishedPages;
  const categories = new Set(docs.map(d => d.category)).size;

  const stats = [
    { title: 'Total Pages', value: totalPages, color: 'text-orange-400' },
    { title: 'Published', value: publishedPages, color: 'text-green-400' },
    { title: 'Drafts', value: draftPages, color: 'text-yellow-400' },
    { title: 'Categories', value: categories, color: 'text-purple-400' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      {stats.map(stat => (
        <Card key={stat.title}>
          <CardHeader>
            <CardTitle className="text-lg">{stat.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-3xl font-bold ${stat.color}`}>{stat.value}</div>
            <p className="text-sm text-gray-400">{stat.title.toLowerCase()}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default DocsStats;
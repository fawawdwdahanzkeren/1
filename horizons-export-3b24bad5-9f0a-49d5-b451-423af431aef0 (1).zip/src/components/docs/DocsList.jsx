import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Eye, Edit, Trash2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const DocsList = ({ docs, onEdit, onDelete }) => {
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {docs.map((doc, index) => (
        <motion.div
          key={doc.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card className="hover-lift h-full flex flex-col">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2 flex-1 min-w-0">
                  <FileText className="w-5 h-5 text-orange-400 flex-shrink-0" />
                  <CardTitle className="text-lg truncate">{doc.title}</CardTitle>
                </div>
                <div className="flex space-x-1 flex-shrink-0">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => window.open(`https://docs.kerenstake.com/${doc.slug}`, '_blank')}
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onEdit(doc)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onDelete(doc.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="flex items-center space-x-2 mt-2">
                <span className="px-2 py-1 rounded-full text-xs bg-blue-500 text-white">
                  {doc.category}
                </span>
                <div className="flex items-center space-x-1">
                  <div className={`w-2 h-2 rounded-full ${doc.published ? 'bg-green-400' : 'bg-gray-400'}`}></div>
                  <span className="text-xs text-gray-400">
                    {doc.published ? 'Published' : 'Draft'}
                  </span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex-grow flex flex-col justify-between">
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-gray-400">Slug</p>
                  <p className="text-sm text-white font-mono truncate">/{doc.slug}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Last Updated</p>
                  <p className="text-sm text-white">{formatDate(doc.updatedAt)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Preview</p>
                  <p className="text-sm text-gray-300 line-clamp-2">
                    {doc.content.replace(/[#*`]/g, '').substring(0, 100)}...
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
};

export default DocsList;
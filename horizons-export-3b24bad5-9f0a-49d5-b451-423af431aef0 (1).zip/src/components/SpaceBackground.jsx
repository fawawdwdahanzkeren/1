
import React from 'react';
import { motion } from 'framer-motion';

const SpaceBackground = ({ animationsEnabled }) => {
  if (!animationsEnabled) return null;

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* Floating Astronaut */}
      <motion.div
        className="absolute top-20 right-20 w-24 h-24 opacity-20"
        animate={{
          y: [0, -20, 0],
          rotate: [0, 5, -5, 0],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      >
        <img  alt="Floating astronaut in space" className="w-full h-full" src="https://images.unsplash.com/photo-1454789548928-9efd52dc4031" />
      </motion.div>

      {/* Rotating Planet */}
      <motion.div
        className="absolute bottom-10 left-10 w-32 h-32 opacity-15"
        animate={{ rotate: 360 }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear"
        }}
      >
        <img  alt="Rotating planet" className="w-full h-full" src="https://images.unsplash.com/photo-1690720909638-fafb99f8bf39" />
      </motion.div>

      {/* Orbiting Small Planet */}
      <motion.div
        className="absolute top-1/2 left-1/2 w-16 h-16"
        style={{ transformOrigin: '0 0' }}
        animate={{ rotate: 360 }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "linear"
        }}
      >
        <div className="absolute -translate-x-20 -translate-y-8 w-8 h-8 opacity-25">
          <img  alt="Small orbiting moon" className="w-full h-full" src="https://images.unsplash.com/photo-1539982070723-118004c9525c" />
        </div>
      </motion.div>

      {/* Floating Stars */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-orange-400 rounded-full opacity-60"
          style={{
            top: `${20 + i * 15}%`,
            left: `${10 + i * 20}%`,
          }}
          animate={{
            scale: [1, 1.5, 1],
            opacity: [0.6, 1, 0.6],
          }}
          transition={{
            duration: 3 + i,
            repeat: Infinity,
            ease: "easeInOut",
            delay: i * 0.5,
          }}
        />
      ))}

      {/* Nebula Effect */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-gradient-radial from-orange-500/20 to-transparent rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-gradient-radial from-blue-500/20 to-transparent rounded-full blur-3xl" />
      </div>
    </div>
  );
};

export default SpaceBackground;

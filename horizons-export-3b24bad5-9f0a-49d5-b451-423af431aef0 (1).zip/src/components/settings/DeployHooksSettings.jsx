import React from 'react';
import { Webhook } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';

const DeployHooksSettings = ({ settings, updateSettings }) => {
  const { toast } = useToast();

  const handleChange = (key, value) => {
    updateSettings('deployHooks', key, value);
  };

  const handleTestAll = () => {
    toast({ title: '🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀' });
  };

  const handleTriggerAll = () => {
    toast({ title: '🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀' });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Webhook className="w-5 h-5 text-orange-400" />
          <span>Deploy Hooks</span>
        </CardTitle>
        <CardDescription>
          Webhook URLs untuk trigger deployment otomatis.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="mainSite">Main Site Hook</Label>
              <Textarea id="mainSite" value={settings.mainSite} onChange={(e) => handleChange('mainSite', e.target.value)} placeholder="https://api.vercel.com/v1/integrations/deploy/..." rows={3} />
            </div>
            <div>
              <Label htmlFor="docs">Documentation Hook</Label>
              <Textarea id="docs" value={settings.docs} onChange={(e) => handleChange('docs', e.target.value)} placeholder="https://api.vercel.com/v1/integrations/deploy/..." rows={3} />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="faucet">Faucet Hook</Label>
              <Textarea id="faucet" value={settings.faucet} onChange={(e) => handleChange('faucet', e.target.value)} placeholder="https://api.vercel.com/v1/integrations/deploy/..." rows={3} />
            </div>
            <div>
              <Label htmlFor="explorer">Explorer Hook</Label>
              <Textarea id="explorer" value={settings.explorer} onChange={(e) => handleChange('explorer', e.target.value)} placeholder="https://api.vercel.com/v1/integrations/deploy/..." rows={3} />
            </div>
          </div>
        </div>
        <div className="flex space-x-4">
          <Button onClick={handleTestAll} variant="outline">Test All Hooks</Button>
          <Button onClick={handleTriggerAll} className="bg-orange-500 hover:bg-orange-600">Trigger All Deployments</Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default DeployHooksSettings;
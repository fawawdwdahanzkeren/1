import React from 'react';
import { Key } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';

const ApiKeysSettings = ({ settings, updateSettings }) => {
  const { toast } = useToast();

  const handleChange = (key, value) => {
    updateSettings('apiKeys', key, value);
  };

  const testConnection = (type) => {
    toast({
      title: 'Testing Connection...',
      description: `Menguji koneksi ${type}...`
    });
    setTimeout(() => {
      toast({
        title: 'Connection Successful!',
        description: `Koneksi ${type} berhasil.`
      });
    }, 1500);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Key className="w-5 h-5 text-orange-400" />
          <span>API Keys</span>
        </CardTitle>
        <CardDescription>
          Kelola API keys untuk integrasi eksternal.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="pocketbaseUrl">PocketBase URL</Label>
              <Input
                id="pocketbaseUrl"
                value={settings.pocketbaseUrl}
                onChange={(e) => handleChange('pocketbaseUrl', e.target.value)}
                placeholder="https://your-pocketbase.com"
              />
            </div>
            <div>
              <Label htmlFor="pocketbaseToken">PocketBase Token</Label>
              <Input
                id="pocketbaseToken"
                type="password"
                value={settings.pocketbaseToken}
                onChange={(e) => handleChange('pocketbaseToken', e.target.value)}
                placeholder="pb_token_here"
              />
            </div>
            <Button
              onClick={() => testConnection('PocketBase')}
              variant="outline"
              className="w-full"
            >
              Test PocketBase Connection
            </Button>
          </div>

          <div className="space-y-4">
            <div>
              <Label htmlFor="recaptchaSiteKey">reCAPTCHA Site Key</Label>
              <Input
                id="recaptchaSiteKey"
                value={settings.recaptchaSiteKey}
                onChange={(e) => handleChange('recaptchaSiteKey', e.target.value)}
                placeholder="6Lc..."
              />
            </div>
            <div>
              <Label htmlFor="recaptchaSecretKey">reCAPTCHA Secret Key</Label>
              <Input
                id="recaptchaSecretKey"
                type="password"
                value={settings.recaptchaSecretKey}
                onChange={(e) => handleChange('recaptchaSecretKey', e.target.value)}
                placeholder="6Lc..."
              />
            </div>
            <Button
              onClick={() => testConnection('reCAPTCHA')}
              variant="outline"
              className="w-full"
            >
              Test reCAPTCHA
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ApiKeysSettings;
import React from 'react';
import { Shield } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';

const SecuritySettings = ({ settings, updateSettings }) => {
  const handleSwitchChange = (key, checked) => {
    updateSettings('security', key, checked);
  };

  const handleInputChange = (key, value) => {
    updateSettings('security', key, parseInt(value) || 0);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-orange-400" />
            <span>Security Settings</span>
          </CardTitle>
          <CardDescription>
            Konfigurasi keamanan dan rate limiting.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium text-white">Enable reCAPTCHA</h3>
              <p className="text-sm text-gray-400">Aktifkan reCAPTCHA untuk faucet.</p>
            </div>
            <Switch
              checked={settings.enableRecaptcha}
              onCheckedChange={(checked) => handleSwitchChange('enableRecaptcha', checked)}
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium text-white">Enable Rate Limiting</h3>
              <p className="text-sm text-gray-400">Batasi jumlah request per jam.</p>
            </div>
            <Switch
              checked={settings.enableRateLimit}
              onCheckedChange={(checked) => handleSwitchChange('enableRateLimit', checked)}
            />
          </div>
          <div>
            <Label htmlFor="maxRequestsPerHour">Max Requests per Hour</Label>
            <Input
              id="maxRequestsPerHour"
              type="number"
              value={settings.maxRequestsPerHour}
              onChange={(e) => handleInputChange('maxRequestsPerHour', e.target.value)}
              placeholder="100"
              className="w-full md:w-1/3"
            />
            <p className="text-sm text-gray-400 mt-1">
              Maksimal request yang diizinkan per alamat IP per jam.
            </p>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>System Status</CardTitle>
          <CardDescription>Status keamanan sistem saat ini.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 glass-card rounded-lg text-center">
              <div className="w-3 h-3 bg-green-400 rounded-full mx-auto mb-2"></div>
              <p className="text-sm text-white font-medium">API Security</p>
              <p className="text-xs text-gray-400">Active</p>
            </div>
            <div className="p-4 glass-card rounded-lg text-center">
              <div className={`w-3 h-3 ${settings.enableRateLimit ? 'bg-green-400' : 'bg-red-400'} rounded-full mx-auto mb-2`}></div>
              <p className="text-sm text-white font-medium">Rate Limiting</p>
              <p className="text-xs text-gray-400">{settings.enableRateLimit ? 'Enabled' : 'Disabled'}</p>
            </div>
            <div className="p-4 glass-card rounded-lg text-center">
              <div className={`w-3 h-3 ${settings.enableRecaptcha ? 'bg-green-400' : 'bg-red-400'} rounded-full mx-auto mb-2`}></div>
              <p className="text-sm text-white font-medium">reCAPTCHA</p>
              <p className="text-xs text-gray-400">{settings.enableRecaptcha ? 'Enabled' : 'Disabled'}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SecuritySettings;

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import Sidebar from '@/components/layout/Sidebar';
import TopBar from '@/components/layout/TopBar';
import Overview from '@/pages/Overview';
import Sites from '@/pages/Sites';
import Networks from '@/pages/Networks';
import Docs from '@/pages/Docs';
import Faucet from '@/pages/Faucet';
import Explorer from '@/pages/Explorer';
import Settings from '@/pages/Settings';
import NotFound from '@/pages/NotFound';
import SpaceBackground from '@/components/SpaceBackground';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [animationsEnabled, setAnimationsEnabled] = useState(true);

  useEffect(() => {
    const saved = localStorage.getItem('kerenstake-animations');
    if (saved !== null) {
      setAnimationsEnabled(JSON.parse(saved));
    }
  }, []);

  const toggleAnimations = () => {
    const newValue = !animationsEnabled;
    setAnimationsEnabled(newValue);
    localStorage.setItem('kerenstake-animations', JSON.stringify(newValue));
  };

  return (
    <Router>
      <div className="min-h-screen space-bg">
        <Helmet>
          <title>KerenStake Dashboard - Admin Panel</title>
          <meta name="description" content="Dashboard admin untuk mengelola ekosistem KerenStake - docs, faucet, explorer, dan main site" />
          <meta property="og:title" content="KerenStake Dashboard - Admin Panel" />
          <meta property="og:description" content="Dashboard admin untuk mengelola ekosistem KerenStake - docs, faucet, explorer, dan main site" />
        </Helmet>
        
        <SpaceBackground animationsEnabled={animationsEnabled} />
        
        <div className="relative z-10 flex h-screen">
          <Sidebar 
            isOpen={sidebarOpen} 
            onClose={() => setSidebarOpen(false)}
            animationsEnabled={animationsEnabled}
            onToggleAnimations={toggleAnimations}
          />
          
          <div className="flex-1 flex flex-col overflow-hidden">
            <TopBar onMenuClick={() => setSidebarOpen(true)} />
            
            <main className="flex-1 overflow-y-auto p-6">
              <Routes>
                <Route path="/" element={<Overview />} />
                <Route path="/sites" element={<Sites />} />
                <Route path="/networks" element={<Networks />} />
                <Route path="/docs" element={<Docs />} />
                <Route path="/faucet" element={<Faucet />} />
                <Route path="/explorer" element={<Explorer />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
          </div>
        </div>
        
        <Toaster />
      </div>
    </Router>
  );
}

export default App;

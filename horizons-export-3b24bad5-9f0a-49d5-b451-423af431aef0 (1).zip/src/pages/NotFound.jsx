
import React from 'react';
import { motion } from 'framer-motion';
import { Home, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Helmet } from 'react-helmet';

const NotFound = () => {
  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <Helmet>
        <title>404 - Halaman Tidak Ditemukan | KerenStake Dashboard</title>
        <meta name="description" content="Halaman yang Anda cari tidak ditemukan di KerenStake Dashboard" />
        <meta property="og:title" content="404 - Halaman Tidak Ditemukan | KerenStake Dashboard" />
        <meta property="og:description" content="Halaman yang Anda cari tidak ditemukan di KerenStake Dashboard" />
      </Helmet>

      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Stars */}
        {[...Array(50)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0.3, 1, 0.3],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 2 + Math.random() * 3,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}

        {/* Floating Nebula */}
        <motion.div
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-radial from-orange-500/10 to-transparent rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        <motion.div
          className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gradient-radial from-blue-500/10 to-transparent rounded-full blur-3xl"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.4, 0.2, 0.4],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center space-y-8 max-w-2xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-9xl font-bold gradient-text mb-4">404</h1>
          <h2 className="text-3xl font-bold text-white mb-4">Halaman Tidak Ditemukan</h2>
          <p className="text-xl text-gray-400 mb-8">
            Sepertinya Anda tersesat di ruang angkasa! Halaman yang Anda cari tidak ada di galaksi ini.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Link to="/">
            <Button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3">
              <Home className="w-5 h-5 mr-2" />
              Kembali ke Dashboard
            </Button>
          </Link>
          <Button 
            variant="outline" 
            onClick={() => window.history.back()}
            className="px-8 py-3"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Halaman Sebelumnya
          </Button>
        </motion.div>

        {/* Floating Astronaut */}
        <motion.div
          className="absolute top-10 right-10 w-32 h-32 opacity-20"
          animate={{
            y: [0, -20, 0],
            rotate: [0, 10, -10, 0],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <img  alt="Lost astronaut floating in space" className="w-full h-full" src="https://images.unsplash.com/photo-1454789548928-9efd52dc4031" />
        </motion.div>

        {/* Floating Planet */}
        <motion.div
          className="absolute bottom-10 left-10 w-24 h-24 opacity-15"
          animate={{ rotate: 360 }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
        >
          <img  alt="Distant planet" className="w-full h-full" src="https://images.unsplash.com/photo-1690720909638-fafb99f8bf39" />
        </motion.div>
      </div>
    </div>
  );
};

export default NotFound;

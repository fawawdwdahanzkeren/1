import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { RefreshCw, AlertCircle, CheckCircle, Clock, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import api from '@/lib/api';

const Faucet = () => {
  const [claims, setClaims] = useState([]);
  const [loading, setLoading] = useState(true);
  const [retrying, setRetrying] = useState({});
  const { toast } = useToast();

  const fetchClaims = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.getFaucetClaims();
      setClaims(data);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Gagal memuat data klaim.',
        variant: 'destructive',
      });
      console.error('Error fetching claims:', error);
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchClaims();
    const interval = setInterval(fetchClaims, 5000); 
    return () => clearInterval(interval);
  }, [fetchClaims]);

  const retryClaim = async (claimId) => {
    setRetrying(prev => ({ ...prev, [claimId]: true }));
    try {
      await api.retryFaucetClaim(claimId);
      toast({
        title: 'Retry Initiated!',
        description: 'Klaim sedang diproses ulang. Status akan diperbarui secara otomatis.'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: `Gagal mencoba ulang klaim: ${error.message}`,
        variant: 'destructive',
      });
    } finally {
      setRetrying(prev => ({ ...prev, [claimId]: false }));
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'sent':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'failed':
        return <AlertCircle className="w-5 h-5 text-red-400" />;
      case 'queued':
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-400" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'sent': return 'text-green-400';
      case 'failed': return 'text-red-400';
      case 'queued':
      case 'pending': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatAddress = (address) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };
  
  const stats = {
    total: claims.length,
    success: claims.filter(c => c.status === 'sent').length,
    failed: claims.filter(c => c.status === 'failed').length,
    pending: claims.filter(c => c.status === 'pending' || c.status === 'queued').length
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Faucet Monitor</h1>
          <p className="text-gray-400 mt-2">Monitor dan kelola klaim faucet</p>
        </div>
        <Button 
          onClick={fetchClaims}
          className="bg-orange-500 hover:bg-orange-600"
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card><CardHeader><CardTitle className="text-lg">Total Claims</CardTitle></CardHeader><CardContent><div className="text-3xl font-bold text-orange-400">{stats.total}</div><p className="text-sm text-gray-400">Semua klaim</p></CardContent></Card>
        <Card><CardHeader><CardTitle className="text-lg">Sent</CardTitle></CardHeader><CardContent><div className="text-3xl font-bold text-green-400">{stats.success}</div><p className="text-sm text-gray-400">Terkirim</p></CardContent></Card>
        <Card><CardHeader><CardTitle className="text-lg">Failed</CardTitle></CardHeader><CardContent><div className="text-3xl font-bold text-red-400">{stats.failed}</div><p className="text-sm text-gray-400">Gagal</p></CardContent></Card>
        <Card><CardHeader><CardTitle className="text-lg">Pending/Queued</CardTitle></CardHeader><CardContent><div className="text-3xl font-bold text-yellow-400">{stats.pending}</div><p className="text-sm text-gray-400">Menunggu</p></CardContent></Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Claims</CardTitle>
          <CardDescription>Daftar klaim faucet terbaru (diperbarui otomatis)</CardDescription>
        </CardHeader>
        <CardContent>
          {loading && claims.length === 0 ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="animate-pulse flex items-center space-x-4 p-4 glass-card rounded-lg">
                  <div className="w-5 h-5 bg-gray-700 rounded-full"></div>
                  <div className="flex-1 space-y-2"><div className="h-4 bg-gray-700 rounded w-1/4"></div><div className="h-3 bg-gray-700 rounded w-1/3"></div></div>
                  <div className="h-8 w-16 bg-gray-700 rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {claims.map((claim, index) => (
                <motion.div
                  key={claim.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  layout
                  transition={{ delay: index * 0.05 }}
                  className="flex items-center justify-between p-4 glass-card rounded-lg hover-lift"
                >
                  <div className="flex items-center space-x-4">
                    {getStatusIcon(claim.status)}
                    <div>
                      <div className="flex items-center space-x-2"><span className="text-white font-medium">{formatAddress(claim.address)}</span><span className="text-xs px-2 py-1 bg-blue-500 rounded-full text-white">{claim.networkName}</span></div>
                      <div className="flex items-center space-x-4 text-sm text-gray-400">
                        <span>{formatDate(claim.createdAt)}</span>
                        {claim.txHash && (
                          <button onClick={() => window.open(`https://etherscan.io/tx/${claim.txHash}`, '_blank')} className="flex items-center space-x-1 text-orange-400 hover:text-orange-300">
                            <span>Tx Hash</span><ExternalLink className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <span className={`text-sm font-medium capitalize ${getStatusColor(claim.status)}`}>{claim.status}</span>
                    {claim.status === 'failed' && (
                      <Button size="sm" onClick={() => retryClaim(claim.id)} disabled={retrying[claim.id]} className="bg-orange-500 hover:bg-orange-600">
                        {retrying[claim.id] ? <RefreshCw className="w-4 h-4 animate-spin" /> : 'Retry'}
                      </Button>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Faucet;
import React from 'react';
import { Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { useSettings } from '@/hooks/useSettings';
import ApiKeysSettings from '@/components/settings/ApiKeysSettings';
import DeployHooksSettings from '@/components/settings/DeployHooksSettings';
import SecuritySettings from '@/components/settings/SecuritySettings';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

const Settings = () => {
  const { settings, loading, saving, updateSettings, saveSettings } = useSettings();
  const { toast } = useToast();

  const handleSave = async () => {
    const success = await saveSettings();
    if (success) {
      toast({
        title: 'Settings Saved!',
        description: 'Pengaturan telah disimpan dengan sukses.'
      });
    } else {
      toast({
        title: 'Error!',
        description: 'Gagal menyimpan pengaturan.',
        variant: 'destructive'
      });
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 bg-gray-700 rounded w-1/4 animate-pulse"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-gray-700 rounded w-3/4"></div>
                <div className="h-3 bg-gray-700 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="h-3 bg-gray-700 rounded"></div>
                  <div className="h-3 bg-gray-700 rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Settings</h1>
          <p className="text-gray-400 mt-2">Konfigurasi sistem KerenStake</p>
        </div>
        <Button 
          onClick={handleSave}
          disabled={saving}
          className="bg-orange-500 hover:bg-orange-600"
        >
          {saving ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
              Saving...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Save Settings
            </>
          )}
        </Button>
      </div>

      <Tabs defaultValue="api-keys" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="api-keys">API Keys</TabsTrigger>
          <TabsTrigger value="deploy-hooks">Deploy Hooks</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="api-keys">
          <ApiKeysSettings settings={settings.apiKeys} updateSettings={updateSettings} />
        </TabsContent>

        <TabsContent value="deploy-hooks">
          <DeployHooksSettings settings={settings.deployHooks} updateSettings={updateSettings} />
        </TabsContent>

        <TabsContent value="security">
          <SecuritySettings settings={settings.security} updateSettings={updateSettings} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
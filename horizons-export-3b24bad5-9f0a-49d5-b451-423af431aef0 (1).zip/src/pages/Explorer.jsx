
    import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Activity, Download, Server } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { toast } from '@/components/ui/use-toast';

const Explorer = () => {
  const [nodes, setNodes] = useState([]);
  const [metrics, setMetrics] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNodes();
    fetchMetrics();
  }, []);

  const fetchNodes = async () => {
    setLoading(true);
    try {
      // Data fallback karena tidak ada endpoint API nyata
      setNodes([
        {
          id: 1,
          name: 'Ethereum Node',
          network: 'Ethereum Mainnet',
          status: 'online',
          uptime: 99.9,
          blockHeight: 18750000,
          lastSnapshot: '2024-01-15T10:30:00Z',
          snapshotSize: '2.1 TB'
        },
        {
          id: 2,
          name: 'Cosmos Hub Node',
          network: 'Cosmos Hub',
          status: 'online',
          uptime: 99.8,
          blockHeight: 17500000,
          lastSnapshot: '2024-01-15T08:15:00Z',
          snapshotSize: '850 GB'
        },
        {
          id: 3,
          name: 'Polygon Node',
          network: 'Polygon',
          status: 'maintenance',
          uptime: 98.5,
          blockHeight: 52000000,
          lastSnapshot: '2024-01-14T20:45:00Z',
          snapshotSize: '1.5 TB'
        }
      ]);
    } catch (error) {
      console.error('Error fetching nodes:', error);
      toast({
        title: "Error",
        description: "Gagal memuat data node.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchMetrics = async () => {
    try {
       // Data fallback karena tidak ada endpoint API nyata
      setMetrics([
        { time: '00:00', uptime: 99.9, height: 18750000 },
        { time: '04:00', uptime: 99.8, height: 18750100 },
        { time: '08:00', uptime: 99.9, height: 18750200 },
        { time: '12:00', uptime: 99.7, height: 18750300 },
        { time: '16:00', uptime: 99.9, height: 18750400 },
        { time: '20:00', uptime: 99.8, height: 18750500 }
      ]);
    } catch (error) {
      console.error('Error fetching metrics:', error);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'online': return 'bg-green-400';
      case 'maintenance': return 'bg-yellow-400';
      case 'offline': return 'bg-red-400';
      default: return 'bg-gray-400';
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleString('id-ID', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const downloadSnapshot = (nodeId) => {
    toast({
      title: '🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀',
      description: `Mempersiapkan snapshot untuk node ID: ${nodeId}.`
    });
  };

  const handleRefresh = () => {
    toast({ title: "Memuat ulang data..." });
    fetchNodes();
    fetchMetrics();
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Explorer Status</h1>
          <p className="text-gray-400 mt-2">Monitor status node dan snapshot</p>
        </div>
        <Button 
          onClick={handleRefresh}
          className="bg-orange-500 hover:bg-orange-600"
        >
          <Activity className="w-4 h-4 mr-2" />
          Refresh All
        </Button>
      </div>

      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {loading ? (
          [...Array(3)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-gray-700 rounded w-3/4"></div>
                <div className="h-3 bg-gray-700 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="h-3 bg-gray-700 rounded"></div>
                  <div className="h-3 bg-gray-700 rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          nodes.map((node) => (
            <motion.div
              key={node.id}
              variants={itemVariants}
            >
              <Card className="hover-lift h-full flex flex-col">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Server className="w-5 h-5 text-orange-400" />
                      <CardTitle className="text-lg">{node.name}</CardTitle>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${getStatusColor(node.status)}`}></div>
                      <span className="text-xs capitalize">{node.status}</span>
                    </div>
                  </div>
                  <CardDescription>{node.network}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-xs text-gray-400">Uptime</p>
                        <p className="text-sm text-white font-medium">{node.uptime}%</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Block Height</p>
                        <p className="text-sm text-white font-medium">{node.blockHeight.toLocaleString()}</p>
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-xs text-gray-400">Last Snapshot</p>
                      <p className="text-sm text-white">{formatDate(node.lastSnapshot)} ({node.snapshotSize})</p>
                    </div>
                  </div>
                  
                  <Button
                    onClick={() => downloadSnapshot(node.id)}
                    className="w-full bg-orange-500 hover:bg-orange-600 mt-4"
                    size="sm"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download Snapshot
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))
        )}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Uptime Trend</CardTitle>
            <CardDescription>Tren uptime node dalam 24 jam terakhir</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={metrics}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" domain={[98, 100]} unit="%" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '0.5rem'
                  }} 
                  labelStyle={{ color: 'hsl(var(--foreground))' }}
                  itemStyle={{ color: '#10B981' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="uptime" 
                  stroke="#10B981" 
                  strokeWidth={2}
                  dot={{ fill: '#10B981', strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Block Height Progress</CardTitle>
            <CardDescription>Progres sinkronisasi blok</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={metrics}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" width={80} tickFormatter={(value) => new Intl.NumberFormat('en', { notation: 'compact' }).format(value)} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '0.5rem'
                  }} 
                  labelStyle={{ color: 'hsl(var(--foreground))' }}
                  itemStyle={{ color: '#F97316' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="height" 
                  stroke="#F97316" 
                  strokeWidth={2}
                  dot={{ fill: '#F97316', strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <Card>
            <CardHeader>
              <CardTitle>Network Overview</CardTitle>
              <CardDescription>Ringkasan status semua jaringan yang dimonitor</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                  <div>
                    <div className="text-3xl font-bold text-green-400">{nodes.filter(n => n.status === 'online').length}</div>
                    <p className="text-sm text-gray-400">Online</p>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-yellow-400">{nodes.filter(n => n.status === 'maintenance').length}</div>
                    <p className="text-sm text-gray-400">Maintenance</p>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-red-400">{nodes.filter(n => n.status === 'offline').length}</div>
                    <p className="text-sm text-gray-400">Offline</p>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-orange-400">{nodes.length}</div>
                    <p className="text-sm text-gray-400">Total Nodes</p>
                  </div>
              </div>
            </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Snapshot Management</CardTitle>
            <CardDescription>Kelola snapshot blockchain untuk pemulihan cepat</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {nodes.map((node) => (
                <div key={node.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 glass-card rounded-lg space-y-3 sm:space-y-0">
                  <div className="flex items-center space-x-4">
                    <div className={`w-3 h-3 rounded-full flex-shrink-0 ${getStatusColor(node.status)}`}></div>
                    <div>
                      <p className="text-white font-medium">{node.name}</p>
                      <p className="text-sm text-gray-400">{node.snapshotSize} • {formatDate(node.lastSnapshot)}</p>
                    </div>
                  </div>
                  <div className="flex space-x-2 self-end sm:self-center">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => toast({ title: '🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀' })}
                    >
                      Generate
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => downloadSnapshot(node.id)}
                      className="bg-orange-500 hover:bg-orange-600"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Explorer;
  
import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Rocket, Plus, Edit, Trash2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import api from '@/lib/api';

const Sites = () => {
  const [sites, setSites] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchSites = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.getSites();
      setSites(data);
    } catch (error) {
      toast({ title: 'Error', description: 'Gagal memuat data situs.', variant: 'destructive' });
      console.error('Error fetching sites:', error);
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchSites();
  }, [fetchSites]);

  const triggerDeploy = async (siteId) => {
    const originalSites = [...sites];
    const siteToDeploy = sites.find(s => s.id === siteId);

    setSites(prev => prev.map(s => s.id === siteId ? { ...s, isDeploying: true } : s));

    try {
      await api.triggerDeploy(siteId);
      toast({
        title: 'Deploy Triggered!',
        description: `Deployment untuk ${siteToDeploy.name} telah dimulai.`
      });
      await fetchSites(); // Re-fetch to get the new lastDeployAt timestamp
    } catch (error) {
      setSites(originalSites);
      toast({ title: 'Error', description: `Gagal memulai deploy: ${error.message}`, variant: 'destructive' });
    } finally {
        setSites(prev => prev.map(s => s.id === siteId ? { ...s, isDeploying: false } : s));
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Belum pernah';
    const date = new Date(dateString);
    return date.toLocaleString('id-ID', {
      dateStyle: 'medium',
      timeStyle: 'short',
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-3xl font-bold gradient-text">Sites Management</h1><p className="text-gray-400 mt-2">Kelola semua subdomain KerenStake</p></div>
        <Button onClick={() => toast({ title: '🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀' })} className="bg-orange-500 hover:bg-orange-600"><Plus className="w-4 h-4 mr-2" />Tambah Site</Button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse"><CardHeader><div className="h-4 bg-gray-700 rounded w-3/4"></div><div className="h-3 bg-gray-700 rounded w-1/2"></div></CardHeader><CardContent><div className="space-y-3"><div className="h-3 bg-gray-700 rounded"></div><div className="h-8 bg-gray-700 rounded"></div></div></CardContent></Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {sites.map((site, index) => (
            <motion.div key={site.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
              <Card className="hover-lift">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center space-x-2"><span>{site.name}</span><div className={`w-2 h-2 rounded-full ${site.enabled ? 'bg-green-400' : 'bg-red-400'}`}></div></CardTitle>
                      <CardDescription>{site.subdomain}</CardDescription>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="icon" onClick={() => toast({ title: '🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀' })}><Edit className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => toast({ title: '🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀' })}><Trash2 className="w-4 h-4" /></Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div><p className="text-sm text-gray-400">Last Deploy:</p><p className="text-sm text-white">{formatDate(site.lastDeployAt)}</p></div>
                    <div className="flex space-x-2">
                      <Button onClick={() => triggerDeploy(site.id)} className="flex-1 bg-orange-500 hover:bg-orange-600" disabled={!site.enabled || site.isDeploying}>
                        {site.isDeploying ? <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>Deploying...</> : <><Rocket className="w-4 h-4 mr-2" />Trigger Deploy</>}
                      </Button>
                      <Button variant="outline" size="icon" onClick={() => window.open(`https://${site.subdomain}`, '_blank')}><ExternalLink className="w-4 h-4" /></Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Sites;
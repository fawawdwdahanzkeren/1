import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, DollarSign, Network, Activity, Globe } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import api from '@/lib/api';

const Overview = () => {
  const [stats, setStats] = useState({ delegators: 0, delegatedAssets: 0, networksCount: 0 });
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const data = await api.getPublicStats();
        setStats(data);
      } catch (error) {
        toast({ title: 'Error', description: 'Gagal memuat statistik publik.', variant: 'destructive' });
        console.error('Error fetching stats:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, [toast]);

  const mockChartData = [
    { name: 'Jan', value: 400 }, { name: 'Feb', value: 300 }, { name: 'Mar', value: 600 },
    { name: 'Apr', value: 800 }, { name: 'May', value: 700 }, { name: 'Jun', value: 900 },
  ];

  const kpiCards = [
    { title: 'Total Delegators', value: stats.delegators.toLocaleString(), icon: Users, change: '+12%', color: 'text-blue-400' },
    { title: 'Delegated Assets', value: `$${(stats.delegatedAssets / 1_000_000).toFixed(1)}M`, icon: DollarSign, change: '+8%', color: 'text-green-400' },
    { title: 'Active Networks', value: stats.networksCount, icon: Network, change: '+2', color: 'text-orange-400' },
    { title: 'Uptime', value: '99.9%', icon: Activity, change: '+0.1%', color: 'text-purple-400' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-3xl font-bold gradient-text">Overview</h1><p className="text-gray-400 mt-2">Ringkasan performa ekosistem KerenStake</p></div>
        <motion.div whileHover={{ scale: 1.05 }} className="flex items-center space-x-2 glass-card px-4 py-2 rounded-lg">
          <Globe className="w-5 h-5 text-orange-400" /><span className="text-sm text-gray-300">Status: Online</span>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiCards.map((kpi, index) => (
          <motion.div key={kpi.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
            <Card className="hover-lift">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">{kpi.title}</CardTitle>
                <kpi.icon className={`h-4 w-4 ${kpi.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{loading ? '...' : kpi.value}</div>
                <p className="text-xs text-green-400 mt-1">{kpi.change} dari bulan lalu</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card><CardHeader><CardTitle>Tren Delegasi</CardTitle><CardDescription>Pertumbuhan delegasi dalam 6 bulan terakhir</CardDescription></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={mockChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" /><XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" /><Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '0.5rem' }} />
                <Line type="monotone" dataKey="value" stroke="#F97316" strokeWidth={2} dot={{ fill: '#F97316', strokeWidth: 2, r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card><CardHeader><CardTitle>Status Jaringan</CardTitle><CardDescription>Monitoring real-time semua jaringan</CardDescription></CardHeader>
          <CardContent><div className="space-y-4">
            {['Ethereum', 'Cosmos Hub', 'Osmosis', 'Juno'].map((network, index) => (<div key={network} className="flex items-center justify-between"><div className="flex items-center space-x-3"><div className="w-3 h-3 bg-green-400 rounded-full"></div><span className="text-white">{network}</span></div><div className="text-sm text-gray-400">{99.9 - index * 0.1}% uptime</div></div>))}
          </div></CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>Aksi Cepat</CardTitle><CardDescription>Shortcut untuk tugas-tugas umum</CardDescription></CardHeader>
        <CardContent><div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Deploy Sites', action: () => navigate('/sites') },
            { label: 'Add Network', action: () => navigate('/networks') },
            { label: 'Update Docs', action: () => navigate('/docs') },
            { label: 'Check Faucet', action: () => navigate('/faucet') }
          ].map((item) => (
            <motion.button key={item.label} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={item.action} className="p-4 glass-card rounded-lg text-center hover:bg-orange-500/10 transition-colors">
              <span className="text-sm text-white">{item.label}</span>
            </motion.button>
          ))}
        </div></CardContent>
      </Card>
    </div>
  );
};

export default Overview;
import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useDocs } from '@/hooks/useDocs';
import DocsList from '@/components/docs/DocsList';
import DocsEditor from '@/components/docs/DocsEditor';
import DocsStats from '@/components/docs/DocsStats';

const Docs = () => {
  const { docs, loading, saveDoc, deleteDoc } = useDocs();
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingDoc, setEditingDoc] = useState(null);

  const handleAddNew = () => {
    setEditingDoc(null);
    setDialogOpen(true);
  };

  const handleEdit = (doc) => {
    setEditingDoc(doc);
    setDialogOpen(true);
  };

  const handleDelete = async (docId) => {
    await deleteDoc(docId);
    toast({
      title: 'Doc Deleted!',
      description: 'Halaman dokumentasi telah dihapus.'
    });
  };

  const handleSave = async (formData) => {
    await saveDoc(formData);
    toast({
      title: editingDoc ? 'Doc Updated!' : 'Doc Created!',
      description: `${formData.title} telah berhasil disimpan.`
    });
    setDialogOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Documentation</h1>
          <p className="text-gray-400 mt-2">Kelola halaman dokumentasi KerenStake</p>
        </div>
        <Button 
          onClick={handleAddNew}
          className="bg-orange-500 hover:bg-orange-600"
        >
          <Plus className="w-4 h-4 mr-2" />
          Tambah Halaman
        </Button>
      </div>

      <DocsEditor
        isOpen={dialogOpen}
        onOpenChange={setDialogOpen}
        doc={editingDoc}
        onSave={handleSave}
      />

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <div className="p-6">
                <div className="h-4 bg-gray-700 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-700 rounded w-1/2"></div>
              </div>
              <CardContent>
                <div className="space-y-3">
                  <div className="h-3 bg-gray-700 rounded"></div>
                  <div className="h-3 bg-gray-700 rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <DocsList docs={docs} onEdit={handleEdit} onDelete={handleDelete} />
      )}

      <DocsStats docs={docs} />
    </div>
  );
};

export default Docs;
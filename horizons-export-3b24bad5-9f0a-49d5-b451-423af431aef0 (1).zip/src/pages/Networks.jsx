import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useNetworks } from '@/hooks/useNetworks';
import NetworkList from '@/components/networks/NetworkList';
import NetworkEditor from '@/components/networks/NetworkEditor';
import NetworkStats from '@/components/networks/NetworkStats';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

const Networks = () => {
  const { networks, loading, saveNetwork, deleteNetwork } = useNetworks();
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingNetwork, setEditingNetwork] = useState(null);

  const handleAddNew = () => {
    setEditingNetwork(null);
    setDialogOpen(true);
  };

  const handleEdit = (network) => {
    setEditingNetwork(network);
    setDialogOpen(true);
  };

  const handleDelete = async (networkId) => {
    await deleteNetwork(networkId);
    toast({
      title: 'Network Deleted!',
      description: 'Network telah dihapus dari sistem.'
    });
  };

  const handleSave = async (formData) => {
    await saveNetwork(formData);
    toast({
      title: editingNetwork ? 'Network Updated!' : 'Network Added!',
      description: `${formData.name} telah berhasil disimpan.`
    });
    setDialogOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Networks</h1>
          <p className="text-gray-400 mt-2">Kelola jaringan blockchain yang didukung</p>
        </div>
        <Button 
          onClick={handleAddNew}
          className="bg-orange-500 hover:bg-orange-600"
        >
          <Plus className="w-4 h-4 mr-2" />
          Tambah Network
        </Button>
      </div>

      <NetworkEditor
        isOpen={dialogOpen}
        onOpenChange={setDialogOpen}
        network={editingNetwork}
        onSave={handleSave}
      />

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-gray-700 rounded w-3/4"></div>
                <div className="h-3 bg-gray-700 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="h-3 bg-gray-700 rounded"></div>
                  <div className="h-3 bg-gray-700 rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <NetworkList networks={networks} onEdit={handleEdit} onDelete={handleDelete} />
      )}

      <NetworkStats networks={networks} />
    </div>
  );
};

export default Networks;
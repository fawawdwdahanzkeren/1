import { useState, useEffect, useCallback } from 'react';
import api from '@/lib/api';

export const useNetworks = () => {
  const [networks, setNetworks] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchNetworks = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.getNetworks();
      setNetworks(data);
    } catch (error) {
      console.error('Error fetching networks:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchNetworks();
  }, [fetchNetworks]);

  const saveNetwork = async (formData) => {
    await api.saveNetwork(formData);
    await fetchNetworks();
  };

  const deleteNetwork = async (networkId) => {
    await api.deleteNetwork(networkId);
    await fetchNetworks();
  };

  return { networks, loading, fetchNetworks, saveNetwork, deleteNetwork };
};
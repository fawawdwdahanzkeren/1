import { useState, useEffect, useCallback } from 'react';
import api from '@/lib/api';

export const useDocs = () => {
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchDocs = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.getDocs();
      setDocs(data);
    } catch (error) {
      console.error('Error fetching docs:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDocs();
  }, [fetchDocs]);

  const saveDoc = async (formData) => {
    await api.saveDoc(formData);
    await fetchDocs();
  };

  const deleteDoc = async (docId) => {
    await api.deleteDoc(docId);
    await fetchDocs();
  };

  return { docs, loading, fetchDocs, saveDoc, deleteDoc };
};
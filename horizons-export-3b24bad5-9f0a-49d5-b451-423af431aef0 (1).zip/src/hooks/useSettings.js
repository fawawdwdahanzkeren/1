import { useState, useEffect, useCallback } from 'react';

const defaultSettings = {
  apiKeys: {
    pocketbaseUrl: '',
    pocketbaseToken: '',
    recaptchaSiteKey: '',
    recaptchaSecretKey: ''
  },
  deployHooks: {
    mainSite: '',
    docs: '',
    faucet: '',
    explorer: ''
  },
  security: {
    enableRecaptcha: true,
    enableRateLimit: true,
    maxRequestsPerHour: 100
  }
};

export const useSettings = () => {
  const [settings, setSettings] = useState(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const loadSettings = useCallback(async () => {
    setLoading(true);
    try {
      // Load from localStorage for demo
      const saved = localStorage.getItem('kerenstake-settings');
      if (saved) {
        setSettings(JSON.parse(saved));
      } else {
        setSettings(defaultSettings);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
      setSettings(defaultSettings);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  const updateSettings = useCallback((section, key, value) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [key]: value
      }
    }));
  }, []);

  const saveSettings = async () => {
    setSaving(true);
    try {
      // Save to localStorage for demo
      localStorage.setItem('kerenstake-settings', JSON.stringify(settings));
      await new Promise(resolve => setTimeout(resolve, 500)); // Simulate async save
      return true;
    } catch (error) {
      console.error('Error saving settings:', error);
      return false;
    } finally {
      setSaving(false);
    }
  };

  return { settings, loading, saving, updateSettings, saveSettings };
};
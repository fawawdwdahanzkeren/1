import crypto from 'crypto';

const sites = [
  { id: crypto.randomUUID(), name: 'KerenStake Main', subdomain: 'kerenstake.com', deployHookUrl: 'https://api.vercel.com/v1/integrations/deploy/hook1', enabled: true, lastDeployAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString() },
  { id: crypto.randomUUID(), name: 'Documentation', subdomain: 'docs.kerenstake.com', deployHookUrl: 'https://api.vercel.com/v1/integrations/deploy/hook2', enabled: true, lastDeployAt: new Date(Date.now() - 5 * 3600 * 1000).toISOString() },
  { id: crypto.randomUUID(), name: 'Faucet', subdomain: 'faucet.kerenstake.com', deployHookUrl: 'https://api.vercel.com/v1/integrations/deploy/hook3', enabled: true, lastDeployAt: new Date(Date.now() - 24 * 3600 * 1000).toISOString() },
  { id: crypto.randomUUID(), name: 'Explorer', subdomain: 'explorer.kerenstake.com', deployHookUrl: 'https://api.vercel.com/v1/integrations/deploy/hook4', enabled: false, lastDeployAt: new Date(Date.now() - 48 * 3600 * 1000).toISOString() }
];

const networks = [
  { id: crypto.randomUUID(), name: 'Ethereum', chainType: 'EVM', rpcUrl: 'https://mainnet.infura.io/v3/YOUR_KEY', faucetAmount: 0.1, cooldownSec: 86400, explorerApiBase: 'https://api.etherscan.io', statusEndpoint: 'https://api.etherscan.io/api', isActive: true, status: 'online' },
  { id: crypto.randomUUID(), name: 'Cosmos Hub', chainType: 'COSMOS', rpcUrl: 'https://rpc-cosmoshub.blockapsis.com', faucetAmount: 1, cooldownSec: 43200, explorerApiBase: 'https://api.cosmos.network', statusEndpoint: 'https://api.cosmos.network/status', isActive: true, status: 'online' },
  { id: crypto.randomUUID(), name: 'Polygon Testnet', chainType: 'EVM', rpcUrl: 'https://rpc-mumbai.maticvigil.com', faucetAmount: 0.5, cooldownSec: 21600, explorerApiBase: 'https://api-testnet.polygonscan.com', statusEndpoint: 'https://api-testnet.polygonscan.com/api', isActive: false, status: 'maintenance' }
];

const docPages = [
  { id: crypto.randomUUID(), title: 'Getting Started', slug: 'getting-started', mdx: '# Getting Started\n\nWelcome to KerenStake!', version: '1.0', published: true, category: 'Basics', updatedAt: new Date().toISOString() },
  { id: crypto.randomUUID(), title: 'Staking Guide', slug: 'staking-guide', mdx: '# How to Stake\n\nFollow these steps...', version: '1.0', published: true, category: 'Guides', updatedAt: new Date().toISOString() },
  { id: crypto.randomUUID(), title: 'API Reference', slug: 'api-reference', mdx: '# API Docs\n\nEndpoints are...', version: '1.0', published: false, category: 'Technical', updatedAt: new Date().toISOString() }
];

const faucetClaims = [
  { id: crypto.randomUUID(), networkId: networks[0].id, address: '0x1234567890123456789012345678901234567890', ipHash: 'hash1', uaHash: 'hash_ua1', txHash: '0xabc...', status: 'sent', createdAt: new Date(Date.now() - 1 * 3600 * 1000).toISOString() },
  { id: crypto.randomUUID(), networkId: networks[1].id, address: 'cosmos1abcdefghijklmnopqrstuvwxyz123456', ipHash: 'hash2', uaHash: 'hash_ua2', txHash: null, status: 'failed', createdAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString() },
  { id: crypto.randomUUID(), networkId: networks[2].id, address: '0x0987654321098765432109876543210987654321', ipHash: 'hash3', uaHash: 'hash_ua3', txHash: null, status: 'queued', createdAt: new Date(Date.now() - 3 * 3600 * 1000).toISOString() },
];

const metricsSnapshots = [
    { id: crypto.randomUUID(), networkId: networks[0].id, height: 18750000, uptimePct: 99.9, peers: 50, votingPower: 123456, timestamp: new Date(Date.now() - 1 * 3600 * 1000).toISOString() },
    { id: crypto.randomUUID(), networkId: networks[0].id, height: 18750100, uptimePct: 99.8, peers: 49, votingPower: 123450, timestamp: new Date(Date.now() - 2 * 3600 * 1000).toISOString() },
];

const statsPublic = {
  delegators: 1247,
  delegatedAssets: 2847392.50,
  networksCount: networks.filter(n => n.isActive).length,
  lastUpdated: new Date().toISOString()
};

const collections = {
    sites,
    networks,
    docPages,
    faucetClaims,
    metricsSnapshots,
    statsPublic
};

console.log('Seeding data to localStorage...');
console.log(`
// --- Instructions ---
// 1. Open your browser's developer console on the dashboard page.
// 2. Copy the code block below.
// 3. Paste it into the console and press Enter.
// 4. Your application's localStorage will be seeded with mock data.
// --------------------

(function() {
  const data = ${JSON.stringify(collections, null, 2)};
  for (const key in data) {
    localStorage.setItem(\`kerenstake_\${key}\`, JSON.stringify(data[key]));
  }
  console.log('✅ Seeding complete! Refresh the page.');
  window.location.reload();
})();
`);